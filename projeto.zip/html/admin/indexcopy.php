<?php
session_start();

include('../../php/conexao.php');
include('../../php/crudAdmin.php');
// include('../../php/busca_avatar.php');

if (isset($_POST['mensagem'])) {
  echo '<script>alert("' . $_POST['mensagem'] . ' ");</script>';
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="../../css/admin.css">
  <link rel="stylesheet" href="../../css/geral.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>
    <?php echo $_SESSION['usuario']; ?>
  </title>
</head>

<body>

  <!-- Tabela de usuários -->
  <div class="listaUsuarios">
    <h2>Usuários</h2>
    <table>
      <tr>
      <th>ID</th>
      <th>Nome</th>
      <th>Senha</th>
      <th>Email</th>
      <th>Tipo</th>
      <th>Foto</th>
      <th>Ações</th>
      </tr>
    <?php
    $users = getUsers();
    $tipos = getTipos();

    if (!empty($users)) {

      foreach ($users as $user) {
        echo '<tr id="row-' . $user["id"] . '">';
        //id
        echo '<td>' . $user["id"] . '</td>';
        //nome
        echo '<td><input type="text" value="' . $user["nome"] . '" name="nome" disabled></td>';
        //password
        echo '<td><input type="password" value="******" name="senha" disabled></td>';
        //email
        echo '<td><input type="text" value="' . $user["email"] . '" name="email" disabled></td>';
        //tipo
        echo '<td><select class="opcao" name="tipo" id="tipo" disabled>';
        foreach ($tipos as $tipo) {
          $selected = ($user["tipo"] === $tipo["tipo"]) ? "selected" : "";
          echo '<option value="' . $tipo["tipo"] . '" ' . $selected . '>' . $tipo["tipo"] . '</option>';
        }
        echo '</select></td>';
        //foto
        echo '<td>';
        echo '<div class="divAvatar">';
        echo '<img class="avatar" src="data:image/png;base64,' . $user["foto"] . '" alt="Avatar" onclick="selecionarImagem()">';
        echo '</div>';
        echo '</td>';
        //ações
        echo '<td class="acoes">';
        echo '<button class="btnAcoes" onclick="habilitarEdicao(' . $user["id"] . ')">Editar</button>';
        echo '<button class="btnAcoes" onclick="salvarEdicao()">Salvar</button>';
        echo '<button class="btnAcoes" onclick="excluirCadastro()">Excluir</button>';
        echo '</td>';
        echo '</tr>';

      }
    } else {
      echo '<tr><td colspan="5">Nenhum usuário encontrado.</td></tr>';
    }
    ?>
    </table>
  </div>
  <script src="/../../js/avatar.js"></script>
</body>

</html>.listaUsuarios th {
background-color: #f2f2f2;
}