<?php

include('conexao.php');

// Função para realizar o SELECT na tabela 'usuarios'
function getUsers()
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM usuarios');
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $users;
}

//buscar lista de tipos
function getTipos(){
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM tipos');
    $stmt->execute();
    $tipos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $tipos;
}

function habilitarEdicao(userId) {
    // Habilitar os campos da linha correspondente ao usuário
    var row = document.getElementById('row-' + userId);
    var inputs = row.getElementsByTagName('input');
    var select = row.getElementsByTagName('select')[0];
  
    for (var i = 0; i < inputs.length; i++) {
      inputs[i].disabled = false;
    }
  
    select.disabled = false;
  }
  

?>